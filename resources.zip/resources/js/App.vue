<template>
  <!-- Auth loading overlay -->
  <div v-if="!authChecked" class="fixed inset-0 z-50 flex items-center justify-center bg-white">
    <div class="flex flex-col items-center gap-3">
      <svg class="animate-spin w-8 h-8 text-brand-brown" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
      </svg>
      <p class="text-sm font-medium text-slate-500">Memuat sesi...</p>
    </div>
  </div>

  <SidebarProvider v-if="authChecked && isAuthenticated">
    <SidebarMobileCloser />
    <Sidebar collapsible="icon">
      <!-- Header: Logo -->
      <SidebarHeader class="border-b border-sidebar-border px-3 py-3 mx-auto">
        <Link href="/" class="flex items-center gap-2 cursor-pointer overflow-hidden">
          <img :src="'/images/logo-ladang-lima-64.png'" alt="Logo" class="h-8 w-8 shrink-0 rounded-md object-contain">
          <span class="font-bold text-brand-brown text-sm truncate group-data-[collapsible=icon]:hidden">TPM Ladang Lima</span>
        </Link>
      </SidebarHeader>

      <!-- Nav Items -->
      <SidebarContent class="px-2 py-4">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton as-child :is-active="isUrl('/')" tooltip="Dashboard">
                  <Link href="/">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    <span>Dashboard</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton as-child :is-active="isUrl('/machines')" tooltip="Machines">
                  <Link href="/machines">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                    <span>Machines</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton as-child :is-active="isUrl('/components')" tooltip="Components">
                  <Link href="/components">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93.398.164.855.142 1.205-.108l.737-.527a1.125 1.125 0 011.45.12l.773.774c.39.389.44 1.002.12 1.45l-.527.737c-.25.35-.272.806-.107 1.204.165.397.505.71.93.78l.893.15c.543.09.94.56.94 1.109v1.094c0 .55-.397 1.02-.94 1.11l-.893.149c-.425.07-.765.383-.93.78-.165.398-.143.854.107 1.204l.527.738c.32.447.269 1.06-.12 1.45l-.774.773a1.125 1.125 0 01-1.449.12l-.738-.527c-.35-.25-.806-.272-1.203-.107-.397.165-.71.505-.781.929l-.149.894c-.09.542-.56.94-1.11.94h-1.094c-.55 0-1.019-.398-1.11-.94l-.148-.894c-.071-.424-.384-.764-.781-.93-.398-.164-.854-.142-1.204.108l-.738.527c-.447.32-1.06.269-1.45-.12l-.773-.774a1.125 1.125 0 01-.12-1.45l.527-.737c.25-.35.273-.806.108-1.204-.165-.397-.505-.71-.93-.78l-.894-.15c-.542-.09-.94-.56-.94-1.109v-1.094c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.765-.383.93-.78.165-.398.143-.854-.107-1.204l-.527-.738a1.125 1.125 0 01.12-1.45l.773-.773a1.125 1.125 0 011.45-.12l.737.527c.35.25.807.272 1.204.107.397-.165.71-.505.78-.929l.15-.894z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <span>Components</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton as-child :is-active="isUrl('/stock')" tooltip="Stock">
                  <Link href="/stock">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/></svg>
                    <span>Stock</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton as-child :is-active="isUrl('/report')" tooltip="Report">
                  <Link href="/report">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6 4h6"/></svg>
                    <span>Report</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton as-child :is-active="isUrl('/approvals')" tooltip="Approval">
                  <Link href="/approvals">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span>Approval</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem v-if="isManagerOrAdmin">
                <SidebarMenuButton as-child :is-active="isUrl('/users')" tooltip="Users">
                  <Link href="/users">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
                    <span>Users</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem v-if="isAdmin">
                <SidebarMenuButton as-child :is-active="isUrl('/notifications')" tooltip="Notifikasi">
                  <Link href="/notifications">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                    <span>Notifikasi</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem v-if="isAdmin">
                <SidebarMenuButton as-child :is-active="isUrl('/logs')" tooltip="System Logs">
                  <Link href="/logs">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
                    <span>System Logs</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <!-- Footer: User profile + logout -->
      <SidebarFooter v-if="user" class="border-t border-sidebar-border p-3">
        <div class="flex items-center gap-3 px-1 py-1.5 mb-2 group-data-[collapsible=icon]:px-0 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:mb-1">
          <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-brand-brown to-brand-gradation flex items-center justify-center font-bold text-brand-cream shadow-md text-xs uppercase shrink-0">
            {{ initials }}
          </div>
          <div class="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
            <p class="text-sm font-bold text-brand-brown truncate leading-tight">{{ user.full_name }}</p>
            <p class="text-xs text-slate-500 font-medium truncate uppercase leading-tight">
              {{ user.role_display_name || getRoleLabel(user.role) }}<span v-if="user.city && user.city !== 'both'"> · {{ cityLabel(user.city) }}</span>
            </p>
          </div>
        </div>
        <button
          @click="handleLogout"
          class="w-full flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold text-red-600 bg-red-50 hover:bg-red-100 rounded-xl transition-all border border-red-100/50 cursor-pointer group-data-[collapsible=icon]:px-2 group-data-[collapsible=icon]:py-2"
        >
          <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
          <span class="group-data-[collapsible=icon]:hidden">Keluar Sistem</span>
        </button>
      </SidebarFooter>
    </Sidebar>

    <!-- Main content area -->
    <SidebarInset class="bg-slate-50 overflow-hidden flex flex-col h-svh">
      <div class="flex-1 overflow-y-auto relative">
        <!-- Floating sidebar toggle + notification bell -->
        <div class="sticky top-0 z-40 flex items-center justify-between gap-2 px-3 py-2 pointer-events-none">
          <SidebarTrigger class="pointer-events-auto text-brand-brown hover:bg-brand-cream border border-sidebar-border shadow-md bg-white cursor-pointer" />
          <NotificationBell class="pointer-events-auto" />
        </div>
        <div class="px-6 md:px-8 pb-8 -mt-2">
          <slot />
        </div>
      </div>
    </SidebarInset>

  </SidebarProvider>

  <!-- Global Alert Modal — always mounted so alertRef is always available -->
  <AlertModal ref="alertModalRef" />
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { Link, usePage, router } from '@inertiajs/vue3';
import { useAuth } from './composables/useAuth.js';
import AlertModal from './components/AlertModal.vue';
import { alertRef } from './composables/useAlert.js';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
} from '../views/components/ui/sidebar/index.ts';
import SidebarMobileCloser from './components/SidebarMobileCloser.vue';
import NotificationBell from './components/NotificationBell.vue';

const page = usePage();
const { user, isAdmin, isManagerOrAdmin, isAuthenticated, authReady, initializeAuth, refreshProfile } = useAuth();
const alertModalRef = ref(null);
const authChecked = ref(false);

onMounted(async () => {
  alertRef.value = alertModalRef.value;
  await initializeAuth();
  authChecked.value = true;
  if (!isAuthenticated.value) {
    router.visit('/login', { replace: true });
  }
});

// Refresh user profile on every Inertia navigation to catch role/permission changes
router.on('navigate', () => {
  refreshProfile();
});

const isUrl = (url) => {
  const currentUrl = page?.url || (typeof window !== 'undefined' ? window.location.pathname : '');
  if (!currentUrl) return false;
  if (url === '/') return currentUrl === '/';
  return currentUrl.startsWith(url);
};

const initials = computed(() => {
  if (!user.value?.full_name) return '??';
  const parts = user.value.full_name.split(' ').filter(n => n.length > 0);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return user.value.full_name.slice(0, 2).toUpperCase();
});

function getRoleLabel(role) {
  const map = { admin: 'Administrator', manager: 'Manajer', technician: 'Teknisi' };
  return map[role] ?? role;
}

function cityLabel(city) {
  const map = { sby: 'Surabaya', pasuruan: 'Pasuruan' };
  return map[city] ?? city;
}

function handleLogout() {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('user_profile');
  window.location.href = '/login';
}
</script>
